const https = require('node:https');

const API_ROOT = 'https://api.donutsmp.net/v1';
const MAX_BODY_BYTES = 32 * 1024;

function response(statusCode, payload) {
  return {
    statusCode,
    headers: {
      'content-type': 'application/json; charset=utf-8',
      'cache-control': 'no-store, max-age=0',
      'x-content-type-options': 'nosniff',
    },
    body: JSON.stringify(payload),
  };
}

function upstreamGet(url, apiKey, requestBody) {
  return new Promise((resolve, reject) => {
    const body = requestBody ? JSON.stringify(requestBody) : '';
    const headers = {
      Authorization: `Bearer ${apiKey}`,
      Accept: 'application/json',
    };
    // The official API documents the listing request as GET with an optional JSON body.
    // node:https permits that request shape; fetch() intentionally does not.
    if (body) {
      headers['content-type'] = 'application/json';
      headers['content-length'] = Buffer.byteLength(body);
    }
    const req = https.request(url, { method: 'GET', headers, timeout: 18000 }, (res) => {
      let raw = '';
      res.setEncoding('utf8');
      res.on('data', (chunk) => {
        raw += chunk;
        if (Buffer.byteLength(raw, 'utf8') > MAX_BODY_BYTES) {
          res.destroy(new Error('DonutSMP API response was too large.'));
        }
      });
      res.on('end', () => {
        let payload;
        try {
          payload = JSON.parse(raw || '{}');
        } catch {
          return resolve({ statusCode: 502, payload: { error: 'DonutSMP returned an unexpected response.' } });
        }
        resolve({ statusCode: res.statusCode || 502, payload });
      });
    });
    req.on('timeout', () => req.destroy(new Error('DonutSMP API request timed out.')));
    req.on('error', (err) => reject(err));
    if (body) req.write(body);
    req.end();
  });
}

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return response(405, { error: 'Use POST for this endpoint.' });
  }

  let payload;
  try {
    const raw = event.isBase64Encoded
      ? Buffer.from(event.body || '', 'base64').toString('utf8')
      : (event.body || '{}');
    if (Buffer.byteLength(raw, 'utf8') > MAX_BODY_BYTES) {
      return response(413, { error: 'Request body is too large.' });
    }
    payload = JSON.parse(raw);
  } catch {
    return response(400, { error: 'Invalid JSON request body.' });
  }

  const apiKey = payload.apiKey;
  if (typeof apiKey !== 'string' || !apiKey.trim() || apiKey.length > 500) {
    return response(400, { error: 'Paste your DonutSMP API key first.' });
  }

  // The frontend sends the requested API path as a query parameter. Only the two
  // documented, read-only auction endpoints are allowed through this relay.
  const route = String(event.queryStringParameters?.route || '').replace(/^\/+/, '');
  const listingMatch = route.match(/^auction\/list\/(\d{1,3})$/);
  const transactionMatch = route.match(/^auction\/transactions\/(\d{1,2})$/);

  let url;
  let requestBody;
  if (listingMatch) {
    const page = Number(listingMatch[1]);
    if (page < 1 || page > 200) return response(400, { error: 'Listing page must be from 1 to 200.' });
    const search = typeof payload.search === 'string' ? payload.search.trim() : '';
    if (search.length > 100) return response(400, { error: 'Search must be 100 characters or fewer.' });
    const allowedSorts = ['lowest_price', 'highest_price', 'recently_listed', 'last_listed'];
    const sort = allowedSorts.includes(payload.sort) ? payload.sort : 'lowest_price';
    url = `${API_ROOT}/auction/list/${page}`;
    requestBody = { search, sort };
  } else if (transactionMatch) {
    const page = Number(transactionMatch[1]);
    if (page < 1 || page > 10) return response(400, { error: 'Transaction page must be from 1 to 10.' });
    url = `${API_ROOT}/auction/transactions/${page}`;
  } else {
    return response(404, { error: 'Endpoint not found. Only read-only auction listings and completed sales are supported.' });
  }

  try {
    const result = await upstreamGet(url, apiKey.trim(), requestBody);
    // Keep upstream API errors intact so the user receives meaningful messages.
    return response(result.statusCode, result.payload);
  } catch (err) {
    return response(502, {
      error: err.message === 'DonutSMP API request timed out.'
        ? err.message
        : 'Could not reach the DonutSMP API. Check your connection and try again.',
    });
  }
};
